#include "mma8452q.h"
#include "i2c.h"

// typedef struct {
//     int angle_x;
//     int angle_y;
//     int angle_z;
// } Angles;

void mma8452q_init(void) {
    // Cấu hình MMA8452Q để bắt đầu đo
    // Cấu hình thanh ghi XYZ_DATA_CFG để thiết lập phạm vi đo ±2g
    i2c_writeToAddress(MMA8452Q_ADDR, XYZ_DATA_CFG, FULL_SCALE_2G);
    _delay_ms(10); // Chờ một chút để cấu hình được thiết lập

    // Cấu hình thanh ghi CTRL_REG1 để thiết lập chế độ hoạt động và tốc độ lấy mẫu
    uint8_t ctrl_reg1_value = ACTIVE_MODE | DATA_RATE_100HZ;
    i2c_writeToAddress(MMA8452Q_ADDR, CTRL_REG1, ctrl_reg1_value);
    _delay_ms(10); // Chờ một chút để cảm biến ổn định
}

uint16_t read_sensor_data(uint8_t msb_reg, uint8_t lsb_reg) {
    uint8_t msb = i2c_readFromAddress(MMA8452Q_ADDR, msb_reg);
    uint8_t lsb = i2c_readFromAddress(MMA8452Q_ADDR, lsb_reg);
    return ((uint16_t)msb << 8) | lsb;
}

// Chuyển đổi giá trị raw thành giá trị gia tốc (g)
float raw_to_g(int16_t raw_value) {
    float g_value = (raw_value / 4096.0f) * 2;
    return g_value;
}

Angles calculate_angles(void) {
    int x_data_raw = read_sensor_data(OUT_X_MSB, OUT_X_LSB);
    int y_data_raw = read_sensor_data(OUT_Y_MSB, OUT_Y_LSB);
    int z_data_raw = read_sensor_data(OUT_Z_MSB, OUT_Z_LSB);

    float ax = raw_to_g(x_data_raw);
    float ay = raw_to_g(y_data_raw);
    float az = raw_to_g(z_data_raw);

    Angles angles;
    angles.angle_x = atan2(ax, sqrt(ay * ay + az * az)) * 180.0f / 3.14159265f;
    angles.angle_y = atan2(ay, sqrt(ax * ax + az * az)) * 180.0f / 3.14159265f;
    angles.angle_z = atan2(az, sqrt(ax * ax + ay * ay)) * 180.0f / 3.14159265f;

    return angles;
}

void process_and_display_angles() {
    char buffer[16];
    Angles angles = calculate_angles();
    ssd1306_clear_line(4);
    ssd1306_clear_line(5);
    ssd1306_clear_line(6);

    // Nếu có dữ liệu từ UART

    if (abs(angles.angle_x) < 20 && abs(angles.angle_y) < 20) {
        PORTB |= (1 << PB0);
        PORTB &= ~(1 << PB1);
        if (abs(angles.angle_x) > abs(angles.angle_y) ){
        uart_transmit_integer(abs(angles.angle_x));
        } else {
        uart_transmit_integer(abs(angles.angle_y));
        }
        _delay_ms(100);
    } else if (abs(angles.angle_x) > 20 || abs(angles.angle_y) > 20) {
        PORTB &= ~(1 << PB0);
        PORTB |= (1 << PB1);
        if (abs(angles.angle_x) > 20 ){
        uart_transmit_integer(abs(angles.angle_x));
        } else {
        uart_transmit_integer(abs(angles.angle_y));
        }
        _delay_ms(100);
    }

    snprintf(buffer, sizeof(buffer), "X: %d", angles.angle_x);
    ssd1306_display_string(0, 4, buffer);

    snprintf(buffer, sizeof(buffer), "Y: %d", angles.angle_y);
    ssd1306_display_string(0, 5, buffer);

    snprintf(buffer, sizeof(buffer), "Z: %d", angles.angle_z);
    ssd1306_display_string(0, 6, buffer);
    
    _delay_ms(5000); // Đợi 5 giây
}