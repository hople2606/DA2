/*
 * DA_TTNT.c
 *
 * Created: 7/11/2024 3:10:40 PM
 * Author : hop
 */ 
#include "main.h"


int main(void)
{
	i2c_init();
	ssd1306_init();
  mma8452q_init();
  ssd1306_display_begin();
	setup();
  
	DDRB |= (1<<PB0);
	DDRB |= (1<<PB1);
  
    while (1) 
    {
    process_and_display_angles();
    }
	
}

